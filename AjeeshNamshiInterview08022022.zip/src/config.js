// Replace the string with your private API key for the News API.

export const NEWS_API_KEY = "cccd952844e241feaff832c3c491364c";
